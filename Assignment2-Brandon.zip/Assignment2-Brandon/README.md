ASSIGNMENT_2

This repository will contain the following files: 1-A climate change excel document showing a table and a chart about the CO2 emissions per country 2-A climate change word document describing the excel file 3-A review of the movie Revolution OS 4-A review of Atom (compared with GitHub
